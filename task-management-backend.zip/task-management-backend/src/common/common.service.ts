import { HttpStatus, Injectable } from '@nestjs/common';
import { ResponseMessage } from './constants/response-message.enum';

@Injectable()
export class CommonService {
  getErrorResponse(
    status = HttpStatus.INTERNAL_SERVER_ERROR,
    message = ResponseMessage.InternalServerError,
  ) {
    return { status: status, message: message };
  }

  getResponse(
    status = HttpStatus.OK,
    message = ResponseMessage.Success,
    data: any = null,
  ) {
    return { status: status, message: message, data: data };
  }
}
