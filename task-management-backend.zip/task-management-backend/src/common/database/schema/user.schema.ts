import mongoose from 'mongoose';
import { User } from 'src/common/interfaces/user.interface';

const UserSchema = new mongoose.Schema<User>({
  email: String,
  password: String,
  role: Number,
});

export default mongoose.model('users', UserSchema);
