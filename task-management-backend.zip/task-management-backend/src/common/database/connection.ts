import mongoose from 'mongoose';

async function createDBConnection() {
  return await mongoose
    .connect('mongodb://127.0.0.1:27017/task-management')
    .then(() => {
      console.log('Database connected successuflly.');
    })
    .catch(() => {
      console.log('Database connection error');
    });
}

export { createDBConnection };
