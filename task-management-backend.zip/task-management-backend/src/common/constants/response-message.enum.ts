export enum ResponseMessage {
  InternalServerError = 'Internal server error',
  Success = 'Success!',

  InvalidCredentials = 'Invalid Credentials',

  EmployeeAdded = 'Employee added successfully.',
  EmployeeFetched = 'Employee fetched successfully.',

  ManagerAdded = 'Manager added successfully.',
  ManagerFetched = 'Manager fetched successfully.',
}
