export enum Role {
  Admin = 0,
  Employee = 1,
  Manager = 2,
}
