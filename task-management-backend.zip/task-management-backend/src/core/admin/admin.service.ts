import { HttpStatus, Injectable, NotFoundException } from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import * as jwt from 'jsonwebtoken';
import { ResponseMessage } from 'src/common/constants/response-message.enum';
import userSchema from 'src/common/database/schema/user.schema';
import { UserLoginDto } from './admin.dto';
import { CommonService } from 'src/common/common.service';

@Injectable()
export class AdminService {
  constructor(private commonService: CommonService) {}

  async login(user: UserLoginDto) {
    const admin = await userSchema.findOne({ email: user.email });
    console.log({ admin, user });

    if (!admin) {
      return this.commonService.getErrorResponse(
        HttpStatus.NOT_FOUND,
        ResponseMessage.InvalidCredentials,
      );
    }

    const isCorrectPassword = bcrypt.compareSync(user.password, admin.password);

    if (!isCorrectPassword) {
      return this.commonService.getErrorResponse(
        HttpStatus.NOT_FOUND,
        ResponseMessage.InvalidCredentials,
      );
    }

    const payload = {
      id: admin._id,
      email: admin.email,
      role: admin.role,
    };

    const token = jwt.sign(payload, 'SECRET', { expiresIn: '1d' });

    return { status: 200, token: token };
  }
}
