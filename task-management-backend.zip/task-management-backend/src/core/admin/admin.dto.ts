export class UserLoginDto {
  email: string;
  password: string;
}
