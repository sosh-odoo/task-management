import { Body, Controller, Post, Res } from '@nestjs/common';
import { AdminService } from './admin.service';
import { UserLoginDto } from './admin.dto';
import { Response } from 'express';

@Controller('admin')
export class AdminController {
  constructor(private adminService: AdminService) {}

  @Post('login')
  async login(@Body() user: UserLoginDto, @Res() res: Response) {
    const response = await this.adminService.login(user);
    res.status(response.status).send(response);
  }
}
