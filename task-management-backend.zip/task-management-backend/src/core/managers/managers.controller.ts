import { Body, Controller, Get, Post, Res } from '@nestjs/common';
import { ManagersService } from './managers.service';
import { Response } from 'express';
import { AddManagerDto } from './managers.dto';

@Controller('admin/managers')
export class ManagersController {
  constructor(private readonly managersService: ManagersService) {}

  @Get('')
  async getEmployees(@Res() res: Response) {
    const response = await this.managersService.getManager();
    return res.status(response.status).send(response);
  }

  @Post('add')
  async addManager(@Body() manager: AddManagerDto, @Res() res: Response) {
    const response = await this.managersService.addManager(manager);
    return res.status(response.status).send(response);
  }
}
