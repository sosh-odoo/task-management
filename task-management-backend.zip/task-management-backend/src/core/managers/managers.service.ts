import { HttpStatus, Injectable } from '@nestjs/common';
import { CommonService } from 'src/common/common.service';
import { ResponseMessage } from 'src/common/constants/response-message.enum';
import userSchema from 'src/common/database/schema/user.schema';
import { Role } from 'src/common/enums/role.enum';
import { AddManagerDto } from './managers.dto';

@Injectable()
export class ManagersService {
  constructor(private commonService: CommonService) {}

  async getManager() {
    const managers = await userSchema.find({ role: Role.Manager });
    return this.commonService.getResponse(
      HttpStatus.OK,
      ResponseMessage.ManagerFetched,
      managers,
    );
  }

  async addManager(manager: AddManagerDto) {
    const newManager = await userSchema.create({
      ...manager,
      role: Role.Manager,
    });
    return this.commonService.getResponse(
      HttpStatus.OK,
      ResponseMessage.ManagerAdded,
      newManager,
    );
  }
}
