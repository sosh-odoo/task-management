import { HttpStatus, Injectable } from '@nestjs/common';
import userSchema from 'src/common/database/schema/user.schema';
import { AddEmployeeDto } from './employess.dto';
import { Role } from 'src/common/enums/role.enum';
import { ResponseMessage } from 'src/common/constants/response-message.enum';
import { CommonService } from 'src/common/common.service';

@Injectable()
export class EmployeesService {
  constructor(private commonService: CommonService) {}

  async getEmployess() {
    const employess = await userSchema.find({ role: Role.Employee });
    return this.commonService.getResponse(
      HttpStatus.OK,
      ResponseMessage.EmployeeFetched,
      employess,
    );
  }

  async addEmployee(employee: AddEmployeeDto) {
    const newEmployee = await userSchema.create({
      ...employee,
      role: Role.Employee,
    });
    return this.commonService.getResponse(
      HttpStatus.OK,
      ResponseMessage.EmployeeAdded,
      newEmployee,
    );
  }
}
