export class AddEmployeeDto {
  name: string;
  email: string;
  password: string;
}
