import { Body, Controller, Get, Post, Res } from '@nestjs/common';
import { EmployeesService } from './employees.service';
import { AddEmployeeDto } from './employess.dto';
import { Response } from 'express';

@Controller('admin/employees')
export class EmployeesController {
  constructor(private readonly employeesService: EmployeesService) {}

  @Get('')
  async getEmployees(@Res() res: Response) {
    const response = await this.employeesService.getEmployess();
    return res.status(response.status).send(response);
  }

  @Post('add')
  async addEmployee(@Body() employee: AddEmployeeDto, @Res() res: Response) {
    console.log({ employee });
    
    const response = await this.employeesService.addEmployee(employee);
    return res.status(response.status).send(response);
  }
}
