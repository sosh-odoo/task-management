import { Module } from '@nestjs/common';
import { EmployeesService } from './employees.service';
import { EmployeesController } from './employees.controller';
import { CommonModule } from 'src/common/common.module';

@Module({
  controllers: [EmployeesController],
  imports: [CommonModule],
  providers: [EmployeesService],
})
export class EmployeesModule {}
