import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import { createDBConnection } from './common/database/connection';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  app.enableCors({ origin: 'http://localhost:4200' });
  await createDBConnection();
  await app.listen(3000);
}
bootstrap();
