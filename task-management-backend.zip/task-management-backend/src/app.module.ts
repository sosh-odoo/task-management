import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AdminModule } from './core/admin/admin.module';
import { MongooseModule } from '@nestjs/mongoose';
import { CommonModule } from './common/common.module';
import { EmployeesModule } from './core/employees/employees.module';
import { ManagersModule } from './core/managers/managers.module';

@Module({
  imports: [
    AdminModule,
    CommonModule,
    EmployeesModule,
    ManagersModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
