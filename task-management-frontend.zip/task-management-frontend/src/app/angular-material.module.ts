import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatTableModule } from '@angular/material/table';
import { MatDialogModule } from '@angular/material/dialog';

const modules = [
  MatIconModule,
  MatCardModule,
  MatInputModule,
  MatCheckboxModule,
  MatSnackBarModule,
  MatButtonModule,
  MatToolbarModule,
  MatTableModule,
  MatDialogModule,
];

@NgModule({
  imports: modules,
  exports: modules,
})
export class AngularMaterialModule {}
