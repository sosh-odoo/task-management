import {
  CdkDragDrop,
  DragDropModule,
  moveItemInArray,
} from '@angular/cdk/drag-drop';
import { Component, OnInit, Signal, signal } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { take } from 'rxjs';
import { AuthService } from '../../../shared/services/auth.service';
import { AdminLoginResponse } from '../../../shared/interfaces/auth.interface';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit {
  isLoading = signal(false);

  loginForm = this.fb.group({
    email: ['', Validators.compose([Validators.required, Validators.email])],
    password: ['', Validators.required],
  });

  constructor(
    private fb: FormBuilder,
    private router: Router,
    private authService: AuthService,
    private snackbar: MatSnackBar
  ) {}

  ngOnInit(): void {}

  login() {
    this.isLoading.set(true);
    if (this.loginForm.value) {
      this.authService.login(this.loginForm.value).subscribe({
        next: (response: AdminLoginResponse) => {
          console.log({ response });
          localStorage.setItem('token', response.token);
          this.isLoading.set(false);
          this.router.navigate(['/dashboard']);
        },
        error: (error) => {
          console.log(error);
          this.snackbar.open(error?.error?.message, 'Ok', {
            horizontalPosition: 'end',
          });
          this.isLoading.set(false);
        },
      });
    }
  }

  hasError(controlName: string, errorName: string) {
    const control = this.loginForm.get(controlName);
    if (control && (control.touched || control.dirty)) {
      return control.hasError(errorName);
    }
    return false;
  }
}
