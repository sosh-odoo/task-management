import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { EmployeeService } from '../../../shared/services/employee.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-employee',
  templateUrl: './edit-employee.component.html',
  styleUrl: './edit-employee.component.scss',
})
export class EditEmployeeComponent implements OnInit {
  employeeForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private employeeService: EmployeeService,
    private snackbar: MatSnackBar,
    private dialogRef: MatDialogRef<EditEmployeeComponent>
  ) {}

  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.employeeForm = this.formBuilder.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
  }

  save() {
    if (this.employeeForm.value) {
      this.employeeService.addEmployee(this.employeeForm.value).subscribe({
        next: (response) => {
          this.dialogRef.close(true);
        },
        error: (error) => {
          console.log(error);
          this.snackbar.open(error?.error?.message, 'Ok', {
            horizontalPosition: 'end',
          });
          this.dialogRef.close(true);
        },
      });
    }
  }

  hasError(controlName: string, errorName: string) {
    const control = this.employeeForm.get(controlName);
    if (control && (control.touched || control.dirty)) {
      return control.hasError(errorName);
    }
    return false;
  }
}
