import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { EditEmployeeComponent } from './edit-employee/edit-employee.component';
import { EmployeeService } from '../../shared/services/employee.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrl: './employee-list.component.scss',
})
export class EmployeeListComponent implements OnInit {
  displayedColumns: string[] = ['_id', 'email','password'];

  dataSource = [];

  constructor(
    private dialog: MatDialog,
    private employeeService: EmployeeService,
    private snackbar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.getEmployess();
  }

  getEmployess() {
    this.employeeService.listEmployess().subscribe({
      next: (response: any) => {
        this.dataSource = response.data;
      },
      error: (error) => {
        console.log(error);
        this.snackbar.open(error?.error?.message, 'Ok', {
          horizontalPosition: 'end',
        });
      },
    });
  }

  onAddEmployee() {
    this.dialog
      .open(EditEmployeeComponent)
      .afterClosed()
      .subscribe((value) => {
        if (value) {
          this.getEmployess();
        }
      });
  }
}
