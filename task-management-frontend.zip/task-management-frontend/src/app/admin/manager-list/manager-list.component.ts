import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ManagerService } from '../../shared/services/manager.service';
import { EditManagerComponent } from './edit-manager/edit-manager.component';

@Component({
  selector: 'app-manager-list',
  templateUrl: './manager-list.component.html',
  styleUrl: './manager-list.component.scss',
})
export class ManagerListComponent {
  displayedColumns: string[] = ['_id', 'email', 'password'];

  dataSource = [];

  constructor(
    private dialog: MatDialog,
    private snackbar: MatSnackBar,
    private managerService: ManagerService
  ) {}

  ngOnInit(): void {
    this.getManagers();
  }

  getManagers() {
    this.managerService.listManagers().subscribe({
      next: (response: any) => {
        this.dataSource = response.data;
      },
      error: (error) => {
        console.log(error);
        this.snackbar.open(error?.error?.message, 'Ok', {
          horizontalPosition: 'end',
        });
      },
    });
  }

  onAddManager() {
    this.dialog
      .open(EditManagerComponent)
      .afterClosed()
      .subscribe((value) => {
        if (value) {
          this.getManagers();
        }
      });
  }
}
