import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ManagerService } from '../../../shared/services/manager.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-edit-manager',
  templateUrl: './edit-manager.component.html',
  styleUrl: './edit-manager.component.scss',
})
export class EditManagerComponent {
  managerForm!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private managerService: ManagerService,
    private snackbar: MatSnackBar,
    private dialogRef: MatDialogRef<EditManagerComponent>
  ) {}

  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.managerForm = this.formBuilder.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required]],
      password: ['', [Validators.required]],
    });
  }

  save() {
    if (this.managerForm.value) {
      this.managerService.addManager(this.managerForm.value).subscribe({
        next: (response) => {
          this.dialogRef.close(true);
        },
        error: (error) => {
          console.log(error);
          this.snackbar.open(error?.error?.message, 'Ok', {
            horizontalPosition: 'end',
          });
          this.dialogRef.close(true);
        },
      });
    }
  }

  hasError(controlName: string, errorName: string) {
    const control = this.managerForm.get(controlName);
    if (control && (control.touched || control.dirty)) {
      return control.hasError(errorName);
    }
    return false;
  }
}
