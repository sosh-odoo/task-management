export interface AdminLoginResponse {
  status: number;
  token: string;
}
