import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { catchError, retry, take, throwError } from 'rxjs';
import { AdminLoginResponse } from '../interfaces/auth.interface';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private readonly baseUrl = environment.API_URL;

  constructor(private http: HttpClient) {}

  login(data: any) {
    return this.http
      .post<AdminLoginResponse>(this.baseUrl + 'admin/login', data)
      .pipe(take(1));
  }
}
