import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { take } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class EmployeeService {
  private readonly baseUrl = environment.API_URL;

  constructor(private http: HttpClient) {}

  listEmployess() {
    return this.http.get(this.baseUrl + 'admin/employees').pipe(take(1));
  }

  addEmployee(data: any) {
    return this.http
      .post(this.baseUrl + 'admin/employees/add', data)
      .pipe(take(1));
  }
}
