import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment.development';
import { HttpClient } from '@angular/common/http';
import { take } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class ManagerService {
  private readonly baseUrl = environment.API_URL;

  constructor(private http: HttpClient) {}

  listManagers() {
    return this.http.get(this.baseUrl + 'admin/managers').pipe(take(1));
  }

  addManager(data: any) {
    return this.http
      .post(this.baseUrl + 'admin/managers/add', data)
      .pipe(take(1));
  }
}
